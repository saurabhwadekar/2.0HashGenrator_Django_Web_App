# hi file mi banavleli aahe - saurabh
from django.http import HttpResponse
from django.shortcuts import render
import hashlib



def hash_gen(hash_type,string): # ha function hash genret karun deto.    
    if hash_type =="md5": # MD5 hash gen
        hash_md5 = hashlib.md5(string.encode('utf-8'))
        hash_value = hash_md5.hexdigest()
    elif hash_type=="sha1": # sha1 hash gen 
        hash_sha1 = hashlib.sha1(string.encode('utf-8'))
        hash_value = hash_sha1.hexdigest()
    elif hash_type=="sha224": # sha224 hash gen 
        hash_sha224 = hashlib.sha224(string.encode('utf-8'))
        hash_value = hash_sha224.hexdigest()
    elif hash_type=="sha256": # sha256 hash gen 
        hash_sha256 = hashlib.sha256(string.encode('utf-8'))
        hash_value = hash_sha256.hexdigest()
    elif hash_type=="sha384": # sha384 hash gen 
        hash_sha384 = hashlib.sha384(string.encode('utf-8'))
        hash_value = hash_sha384.hexdigest()
    elif hash_type=="sha512": # sha512 hash gen 
        hash_sha512 = hashlib.sha512(string.encode('utf-8'))
        hash_value = hash_sha512.hexdigest()
    elif hash_type=="blake2b": # blake2b hash gen. 
        hash_blake2b = hashlib.blake2b(string.encode('utf-8'))
        hash_value = hash_blake2b.hexdigest()
    elif hash_type=="blake2s": # blake2s hash gen
        hash_blake2s = hashlib.blake2s(string.encode('utf-8'))
        hash_value = hash_blake2s.hexdigest()
    else: # not mach hash type
        hash_value = "hash not valid"
    return hash_value # return hash genreted value    

# def index(request):
#     return HttpResponse('''<h1>index page</h1></br><a href="https://google.com">Google</a>''')


def index(request):
    hashes={"br":""}
    string_text = request.GET.get('string','no_str')
    encription_type = request.GET.get('encription','no_en')

    if string_text != 'no_str' and encription_type != "no_en":
        ss = f"""
        <label for="exampleFormControlSelect1">Your string  </label>
        <input class="form-control" type="text" placeholder="{string_text}" readonly>
        """
        hash_type_list = ["md5","sha1","sha224","sha256","sha384","sha512","blake2b","blake2s"]

        if encription_type not in hash_type_list:
            encription_type = "md5"
        hash_get = str(hash_gen(encription_type,string_text))

        gg= f"""
        <label for="exampleFormControlSelect1">Your {encription_type} hash </label>
        <input class="form-control" type="text" placeholder="{hash_get}" readonly>
        """
        hashes={"br":f"""{ss}{gg}"""}
        return render(request,"index.html",hashes)


    return render(request,"index.html")

